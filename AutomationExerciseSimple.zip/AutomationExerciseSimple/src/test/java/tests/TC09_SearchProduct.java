package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC09_SearchProduct extends BaseTest {

    @Test(description = "Search Product")
    public void searchProduct() {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Click 'Products' button
        driver.findElement(By.xpath("//a[@href='/products']")).click();

        // 5. Verify ALL PRODUCTS page
        String pageTitle = driver.findElement(By.xpath("//h2[@class='title text-center']")).getText();
        Assert.assertTrue(pageTitle.contains("ALL PRODUCTS"), "Not on products page");

        // 6. Enter product name and click search
        driver.findElement(By.id("search_product")).sendKeys("Top");
        driver.findElement(By.id("submit_search")).click();

        // 7. Verify 'SEARCHED PRODUCTS' is visible
        String searchTitle = driver.findElement(By.xpath("//h2[text()='Searched Products']")).getText();
        Assert.assertEquals(searchTitle, "SEARCHED PRODUCTS", "Search title not visible");

        // 8. Verify search results are visible
        int searchResults = driver.findElements(By.cssSelector(".features_items .col-sm-4")).size();
        Assert.assertTrue(searchResults > 0, "No search results found");

        System.out.println("✓ TC09 Passed - Product search works");
    }
}