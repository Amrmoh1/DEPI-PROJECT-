package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC10_SubscriptionHome extends BaseTest {

    @Test(description = "Verify Subscription in home page")
    public void verifySubscriptionInHomePage() {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Scroll down to footer
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

        // 5. Verify text 'SUBSCRIPTION'
        String subscriptionText = driver.findElement(By.xpath("//h2[text()='Subscription']")).getText();
        Assert.assertEquals(subscriptionText, "SUBSCRIPTION", "Subscription text not found");

        // 6. Enter email and click arrow button
        driver.findElement(By.id("susbscribe_email")).sendKeys("test@example.com");
        driver.findElement(By.id("subscribe")).click();

        // 7. Verify success message
        String successMsg = driver.findElement(By.xpath("//div[@class='alert-success alert']")).getText();
        Assert.assertTrue(successMsg.contains("successfully subscribed"), "Success message not shown");

        System.out.println("✓ TC10 Passed - Home page subscription works");
    }
}