package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC11_SubscriptionCart extends BaseTest {

    @Test(description = "Verify Subscription in Cart page")
    public void verifySubscriptionInCartPage() {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Click 'Cart' button
        driver.findElement(By.xpath("//a[@href='/view_cart']")).click();

        // 5. Scroll down to footer
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

        // 6. Verify text 'SUBSCRIPTION'
        String subscriptionText = driver.findElement(By.xpath("//h2[text()='Subscription']")).getText();
        Assert.assertEquals(subscriptionText, "SUBSCRIPTION", "Subscription text not found");

        // 7. Enter email and click arrow button
        driver.findElement(By.id("susbscribe_email")).sendKeys("test@example.com");
        driver.findElement(By.id("subscribe")).click();

        // 8. Verify success message
        String successMsg = driver.findElement(By.xpath("//div[@class='alert-success alert']")).getText();
        Assert.assertTrue(successMsg.contains("successfully subscribed"), "Success message not shown");

        System.out.println("✓ TC11 Passed - Cart page subscription works");
    }
}