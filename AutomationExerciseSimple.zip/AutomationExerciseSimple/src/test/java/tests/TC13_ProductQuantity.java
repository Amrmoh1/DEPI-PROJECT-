package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC13_ProductQuantity extends BaseTest {

    @Test(description = "Verify Product quantity in Cart")
    public void verifyProductQuantityInCart() throws InterruptedException {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Click 'View Product' for any product
        driver.findElement(By.xpath("(//a[contains(text(),'View Product')])[1]")).click();

        // 5. Verify product detail page opened
        boolean isProductNameVisible = driver.findElement(By.xpath("//div[@class='product-information']/h2")).isDisplayed();
        Assert.assertTrue(isProductNameVisible, "Product page not opened");

        // 6. Increase quantity to 4
        driver.findElement(By.id("quantity")).clear();
        driver.findElement(By.id("quantity")).sendKeys("4");

        // 7. Click 'Add to cart'
        driver.findElement(By.xpath("//button[@type='button']")).click();

        // 8. Click 'View Cart'
        Thread.sleep(1000);
        driver.findElement(By.xpath("//u[text()='View Cart']")).click();

        // 9. Verify quantity is 4
        String quantity = driver.findElement(By.cssSelector(".cart_quantity button")).getText();
        Assert.assertEquals(quantity, "4", "Quantity is not 4");

        System.out.println("✓ TC13 Passed - Product quantity verified");
    }
}