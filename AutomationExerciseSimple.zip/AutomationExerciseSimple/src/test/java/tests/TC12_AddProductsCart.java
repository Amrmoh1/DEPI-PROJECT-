package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC12_AddProductsCart extends BaseTest {

    @Test(description = "Add Products in Cart")
    public void addProductsInCart() throws InterruptedException {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Click 'Products' button
        driver.findElement(By.xpath("//a[@href='/products']")).click();

        // 5. Hover over first product and click 'Add to cart'
        WebElement firstProduct = driver.findElement(By.xpath("(//a[@data-product-id='1'])[1]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", firstProduct);
        js.executeScript("arguments[0].click();", firstProduct);

        // 6. Click 'Continue Shopping'
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[text()='Continue Shopping']")).click();

        // 7. Hover over second product and click 'Add to cart'
        WebElement secondProduct = driver.findElement(By.xpath("(//a[@data-product-id='2'])[1]"));
        js.executeScript("arguments[0].scrollIntoView(true);", secondProduct);
        js.executeScript("arguments[0].click();", secondProduct);

        // 8. Click 'View Cart'
        Thread.sleep(1000);
        driver.findElement(By.xpath("//u[text()='View Cart']")).click();

        // 9. Verify both products are in cart
        int productsInCart = driver.findElements(By.xpath("//tbody/tr")).size();
        Assert.assertEquals(productsInCart, 2, "Both products not in cart");

        // 10. Verify prices, quantity and total
        String firstQty = driver.findElement(By.xpath("(//td[@class='cart_quantity']/button)[1]")).getText();
        Assert.assertEquals(firstQty, "1", "First product quantity wrong");

        String secondQty = driver.findElement(By.xpath("(//td[@class='cart_quantity']/button)[2]")).getText();
        Assert.assertEquals(secondQty, "1", "Second product quantity wrong");

        System.out.println("✓ TC12 Passed - Products added to cart successfully");
    }
}