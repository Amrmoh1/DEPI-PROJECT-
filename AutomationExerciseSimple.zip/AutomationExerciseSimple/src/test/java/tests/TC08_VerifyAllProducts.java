package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC08_VerifyAllProducts extends BaseTest {

    @Test(description = "Verify All Products and product detail page")
    public void verifyAllProductsAndDetails() {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Click 'Products' button
        driver.findElement(By.xpath("//a[@href='/products']")).click();

        // 5. Verify ALL PRODUCTS page
        String pageTitle = driver.findElement(By.xpath("//h2[@class='title text-center']")).getText();
        Assert.assertTrue(pageTitle.contains("ALL PRODUCTS"), "Not on products page");

        // 6. Products list is visible
        int productsCount = driver.findElements(By.cssSelector(".features_items .col-sm-4")).size();
        Assert.assertTrue(productsCount > 0, "No products found");

        // 7. Click 'View Product' of first product
        driver.findElement(By.xpath("(//a[contains(text(),'View Product')])[1]")).click();

        // 8 & 9. Verify product details are visible
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']/h2")).isDisplayed(), "Product name not visible");
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']/p[1]")).isDisplayed(), "Category not visible");
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']/span/span")).isDisplayed(), "Price not visible");
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']/p[2]/b")).isDisplayed(), "Availability not visible");
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']/p[3]/b")).isDisplayed(), "Condition not visible");
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='product-information']/p[4]/b")).isDisplayed(), "Brand not visible");

        System.out.println("✓ TC08 Passed - All product details verified");
    }
}