package tests;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.Random;

public class TC14_PlaceOrder extends BaseTest {

    @Test(description = "Place Order: Register while Checkout")
    public void placeOrderRegisterWhileCheckout() throws InterruptedException {
        // 3. Verify home page is visible
        boolean isLogoDisplayed = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
        Assert.assertTrue(isLogoDisplayed, "Home page not visible");

        // 4. Add products to cart
        driver.findElement(By.xpath("//a[@href='/products']")).click();
        WebElement firstProduct = driver.findElement(By.xpath("(//a[@data-product-id='1'])[1]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", firstProduct);
        js.executeScript("arguments[0].click();", firstProduct);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//button[text()='Continue Shopping']")).click();

        // 5. Click 'Cart' button
        driver.findElement(By.xpath("//a[@href='/view_cart']")).click();

        // 6. Verify cart page displayed
        boolean isCartDisplayed = driver.findElement(By.id("cart_info_table")).isDisplayed();
        Assert.assertTrue(isCartDisplayed, "Cart not displayed");

        // 7. Click Proceed To Checkout
        driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();

        // 8. Click 'Register / Login' button
        Thread.sleep(1000);
        driver.findElement(By.xpath("//u[text()='Register / Login']")).click();

        // 9. Fill signup details and create account
        driver.findElement(By.name("name")).sendKeys("Ali Alashkar");
        driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys("alialashkar654@gmail.com");
        driver.findElement(By.xpath("//button[@data-qa='signup-button']")).click();

        // Fill account information
        driver.findElement(By.id("id_gender1")).click();
        driver.findElement(By.id("password")).sendKeys("Password123");

        new Select(driver.findElement(By.id("days"))).selectByValue("01");
        new Select(driver.findElement(By.id("months"))).selectByValue("1");
        new Select(driver.findElement(By.id("years"))).selectByValue("2005");

        driver.findElement(By.id("newsletter")).click();
        driver.findElement(By.id("optin")).click();

        // Fill address information
        driver.findElement(By.id("first_name")).sendKeys("Ali");
        driver.findElement(By.id("last_name")).sendKeys("Alashkar");
        driver.findElement(By.id("company")).sendKeys("Google");
        driver.findElement(By.id("address1")).sendKeys("1 Madint naser Elzhour");
        driver.findElement(By.id("address2")).sendKeys("1 settlment Elbanfsg 10");

        new Select(driver.findElement(By.id("country"))).selectByValue("Egypt");

        driver.findElement(By.id("state")).sendKeys("New cairo");
        driver.findElement(By.id("city")).sendKeys("New cairo");
        driver.findElement(By.id("zipcode")).sendKeys("20000");
        driver.findElement(By.id("mobile_number")).sendKeys("01127718939");

        driver.findElement(By.xpath("//button[@data-qa='create-account']")).click();

        // 10. Verify 'ACCOUNT CREATED!'
        boolean isAccountCreated = driver.findElement(By.xpath("//b[text()='Account Created!']")).isDisplayed();
        Assert.assertTrue(isAccountCreated, "Account not created");
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();

        // 11. Verify logged in
        boolean isLoggedIn = driver.findElement(By.xpath("//i[@class='fa fa-user']/parent::a")).isDisplayed();
        Assert.assertTrue(isLoggedIn, "User not logged in");

        // 12. Click 'Cart' button
        driver.findElement(By.xpath("//a[@href='/view_cart']")).click();

        // 13. Click 'Proceed To Checkout'
        driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();

        // 14. Verify Address Details
        Assert.assertTrue(driver.findElement(By.xpath("//ul[@id='address_delivery']")).isDisplayed());
        Assert.assertTrue(driver.findElement(By.xpath("//ul[@id='address_invoice']")).isDisplayed());

        // 15. Enter comment and click 'Place Order'
        driver.findElement(By.name("message")).sendKeys("Test order");
        driver.findElement(By.xpath("//a[@href='/payment']")).click();

        // 16. Enter payment details
        driver.findElement(By.name("name_on_card")).sendKeys("Ali Alashkar");
        driver.findElement(By.name("card_number")).sendKeys("111111111111111");
        driver.findElement(By.name("cvc")).sendKeys("555");
        driver.findElement(By.name("expiry_month")).sendKeys("09");
        driver.findElement(By.name("expiry_year")).sendKeys("2030");

        // 17. Click 'Pay and Confirm Order'
        driver.findElement(By.id("submit")).click();

        // 18. Verify success message
        boolean isSuccess = driver.findElement(By.xpath("//p[contains(text(),'Congratulations')]")).isDisplayed();
        Assert.assertTrue(isSuccess, "Order not placed");

        // 19. Click 'Delete Account'
        driver.findElement(By.xpath("//a[@href='/delete_account']")).click();

        // 20. Verify 'ACCOUNT DELETED!'
        boolean isDeleted = driver.findElement(By.xpath("//b[text()='Account Deleted!']")).isDisplayed();
        Assert.assertTrue(isDeleted, "Account not deleted");
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();

        System.out.println("✓ TC14 Passed - Order placed and account deleted");
    }
}